-- ============================================================
-- CashPilot - Schema do Banco de Dados
-- ============================================================

CREATE DATABASE IF NOT EXISTS cashpilot CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cashpilot;

-- ------------------------------------------------------------
-- Tabela: usuarios
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL,
    tipo_perfil ENUM('pessoa_fisica', 'mei') NOT NULL DEFAULT 'pessoa_fisica',
    renda_mensal DECIMAL(12,2) DEFAULT 0.00,
    data_cadastro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: categorias
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nome VARCHAR(80) NOT NULL,
    tipo ENUM('receita', 'despesa') NOT NULL,
    cor VARCHAR(7) DEFAULT '#4B5945',
    padrao TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: receitas
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS receitas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    categoria_id INT NULL,
    valor DECIMAL(12,2) NOT NULL,
    descricao VARCHAR(180) NOT NULL,
    data_receita DATE NOT NULL,
    data_cadastro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: despesas
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS despesas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    categoria_id INT NULL,
    valor DECIMAL(12,2) NOT NULL,
    descricao VARCHAR(180) NOT NULL,
    data_despesa DATE NOT NULL,
    data_cadastro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Tabela: metas
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS metas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    titulo VARCHAR(120) NOT NULL,
    valor_meta DECIMAL(12,2) NOT NULL,
    valor_atual DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    prazo DATE NULL,
    data_criacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    concluida TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- Trigger: cria categorias padrão automaticamente para todo
-- novo usuário cadastrado
-- ============================================================
DELIMITER $$
CREATE TRIGGER IF NOT EXISTS trg_categorias_padrao
AFTER INSERT ON usuarios
FOR EACH ROW
BEGIN
    INSERT INTO categorias (usuario_id, nome, tipo, cor, padrao) VALUES
    (NEW.id, 'Salário', 'receita', '#4B5945', 1),
    (NEW.id, 'Vendas', 'receita', '#3B6E71', 1),
    (NEW.id, 'Serviços', 'receita', '#7A6A53', 1),
    (NEW.id, 'Investimentos', 'receita', '#5A6E5D', 1),
    (NEW.id, 'Outros', 'receita', '#8A8A8A', 1),
    (NEW.id, 'Alimentação', 'despesa', '#B5654A', 1),
    (NEW.id, 'Transporte', 'despesa', '#6B7280', 1),
    (NEW.id, 'Moradia', 'despesa', '#4B5563', 1),
    (NEW.id, 'Educação', 'despesa', '#3B6E71', 1),
    (NEW.id, 'Saúde', 'despesa', '#7A3B3B', 1),
    (NEW.id, 'Lazer', 'despesa', '#8A7B5A', 1),
    (NEW.id, 'Tecnologia', 'despesa', '#4B5945', 1),
    (NEW.id, 'Fornecedores', 'despesa', '#5A5A5A', 1),
    (NEW.id, 'Impostos', 'despesa', '#3F3F3F', 1),
    (NEW.id, 'Outros', 'despesa', '#8A8A8A', 1);
END$$
DELIMITER ;
